# Provenance and license

All SVG artwork and metadata authored for this archive are released under CC0 1.0 Universal. No third-party images, fonts, game extracts, Blizzard assets or Warcraft III retail files are included. Warcraft is a trademark of Blizzard Entertainment; this independent project is not affiliated with or endorsed by Blizzard.
