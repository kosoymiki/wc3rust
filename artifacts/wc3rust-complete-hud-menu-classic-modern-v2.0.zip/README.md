# wc3rust Complete HUD & Menu Asset Pack v2.0.0

Original clean-room SVG art in a Classic + Modern dark medieval fantasy direction. Includes 16 gameplay panels, button/slot/tab states, portrait frames, 51 original glyph icons for resources, commands, unit classes, abilities, items and UI actions, 7 menu surfaces, manifest, atlas index, previews and integration notes.

No Blizzard/Warcraft retail artwork, logos, extracted assets, maps or fonts are included. SVG sources are resolution-independent. This is a source art pack, not a claim of runtime integration or screenshot QA.
