# Visual guidelines

Soot/ink foundations, carved warm stone, aged oak, bronze edging and muted gold highlights. Keep ornament on panel boundaries and preserve calm content regions. Gold indicates focus/selection, not every edge. Disabled states remain distinguishable. Avoid permanent control-group trays; control-group mechanics remain an input/gameplay concern.
