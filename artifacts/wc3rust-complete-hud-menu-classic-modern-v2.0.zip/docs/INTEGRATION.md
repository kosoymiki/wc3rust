# Integration contract

Use manifest.json as the authoritative inventory. SVG is source artwork; rasterize deterministically at target density, preserving alpha and sRGB. Apply nine-slice insets to panels only. Select button/slot variants by semantic UI state, never texture index. Draw and hit-test from one semantic geometry source. This pack defines no gameplay actions or hotkeys. Game-specific portraits, map thumbnails and item/spell art must come from the licensed game-data pipeline. No runtime integration is asserted.
