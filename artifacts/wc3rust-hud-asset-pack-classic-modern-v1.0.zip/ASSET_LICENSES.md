# Asset licenses and provenance

All included artwork is original vector geometry created for this pack. No retail game files, ripped textures, or retail fonts are included. CC0 1.0 Universal applies to included artwork and metadata, including commercial use. External additions are not covered; track provenance and license separately.
