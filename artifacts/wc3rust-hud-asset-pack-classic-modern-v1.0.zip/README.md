# wc3rust HUD & Menu Asset Pack - Classic + Modern

Original vector-first RTS UI art. Includes modular panels, five button states, frame pieces, original resource/command/status/menu pictograms, menu backdrop and modal panel. No extracted Warcraft III/Blizzard artwork.

SVG is source art: rasterize and atlas-pack at build time, never in the frame loop. Keep text localized and live. Use semantic IDs; draw and hit-test from the same solved bounds. No permanent control-group tray. Foundational pack; game-specific portraits, spell/item illustrations and map thumbnails require verified game content.
