# Integration Contract

1. Validate manifest and required assets at build/startup, never per frame.
2. Reject duplicate IDs, missing files and invalid dimensions.
3. Semantic IDs are stable API; never use array positions.
4. UI state owns availability; artwork does not implement game rules.
5. Renderer owns rasterization, atlas packing, texture upload and GPU lifetime.
6. Draw and hit-test use the same solved element bounds.
