# Visual Guidelines

- Dark stone structural frames; restrained bronze/gold trim.
- Dark timber for navigation; deep neutral content fields.
- Bright gold reserved for hover, focus and selected states.
- Disabled remains legible and distinct from pressed.
- Keep text live/localized; do not bake labels into artwork.
- No permanent ten-slot control-group tray.
- Minimap camera, fog and blips must come from game state.
